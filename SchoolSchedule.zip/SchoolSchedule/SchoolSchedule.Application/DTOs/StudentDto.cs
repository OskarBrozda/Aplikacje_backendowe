﻿namespace SchoolSchedule.Application.DTOs
{
    public class StudentDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
