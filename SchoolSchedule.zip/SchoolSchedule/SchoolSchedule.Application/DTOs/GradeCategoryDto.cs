﻿namespace SchoolSchedule.Application.DTOs
{
    public class GradeCategoryDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
